<?php include("config.php"); include "header.php";?>
<!DOCTYPE html>
<head>
	
	<title>Janji Temu</title>
	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">

	<!-- Bootstrap-->
	<!--<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />-->

	<!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="css/styleform.css"/>
</head>

<body>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<center>
		
	<!--<p><fieldset>
	<legend>Maklumat Peribadi</legend>-->

	 <!--<div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">-->

 <div class="wrapper">
 	
    <div class="title">Borang Janji Temu Pelajar
		</div>
		<div style >Pelajar WAJIB menjawab  soalan dibawah</div>
		<BR>
		
			<form method="POST" action="janjitemu.php">
				<div class="form">
   
		<!--<div style="background-color:grey; width:900px; height: 700px;">-->
	
	<!--<div class="form-group mb-3">
	
		<label for="nama">Nama :</label>
		<input type="text" name="nama" id="nama" placeholder="Masukkan nama penuh anda"></p>

	</div>-->

		

	


<br>
<div class="inputfield">
		<label for="tarikh">Tarikh Janji Temu:</label><br>
		<input type="date" name="tarikh" id="tarikh" style="resize:none;  width: 100%;padding:10px 15px;font-size: 17px;margin:8px 0;background: #eee;border-radius: 5px;" >
</div>

<br>
<div class="inputfield">
		<label for="waktu">Waktu :</label><br>
		<select name="waktu" id="waktu" style="resize:none;  width: 100%;padding:10px 15px;font-size: 17px;margin:8px 0;background: #eee;border-radius: 5px;">
		<div class="custom_select">
		<option>Pilih waktu janji temu di sini</option>
		<option value ="pagi">9.00 A.M</option>
		<option value ="petang">3.00 P.M</option>
		</select>
</div>

<br><br>
<div class="inputfield">
<input type="submit"  class="btn" name="submit"  value="SELESAI" width="200" " onclick="msg()">&nbsp;
<script>
function msg(){
alert("Permohonan sedang diproses");
}</script></div>
<div class="inputfield">
<input type="reset" class="btn" name="reset" value="KEMBALI">&nbsp;</div>

</div></div></div>

</form>
<!--NANTI LETAK UPDATE.PHP DEKAT SINI-->
</fieldset>

<?php

if (isset($_POST['submit'])) {
	
	$waktu=$_POST['waktu'];
	$tarikh=$_POST['tarikh'];
	
		
/*$query="INSERT INTO user_form(nama,nokp, notel, notelpen, waktu, tarikh,alamat,program, tahun, jantina) VALUES 
('$nama','$nokp','$notel','$notelpen','$waktu','$tarikh','$alamat','$program','$tahun','$jantina')";

$result=mysqli_query($conn,"INSERT INTO janji_temu VALUES 
('$waktu','$tarikh')");
if($result){
	echo"Success";
}
else{
	echo"failed";
}
}
mysqli_query($conn,$query);

echo "<script>alert('Data sedang diprose, Sila tunggu');</script>";*/
}
//klau nk masuk insert dkt sini
include("config.php");
include("insert.php");

/*else {
	$nama="";
	$kp="";
	$tarikhlahir="";
	$adekberadek="";
	$blog="";
	$warna="";
	$alamat="";
	$notel="";
	$email="";
	$jantina="";
	$program="";
	$bidang="";
	$kemahiran="";
}
?>
<div id="maklumat">
<div>Nama:<?php echo $nama;?></div>
<div>No. KP:<?php echo $kp;?></div>
<div>Tarikh Lahir:<?php echo $tarikhlahir;?></div>
<div>Bilangan adik-beradik:<?php echo $adekberadek;?></div>
<div>Warna Kegemaran:<?php echo $warna;?></div>
<div>Alamat:<?php echo $alamat;?></div>
<div>No. Tel:<?php echo $notel;?></div>
<div>E-mel:<?php echo $email;?></div>
<div>Jantina:<?php echo $jantina;?></div>
<div>Program:<?php echo $program;?></div>
<div>Alamat Blog:<?php echo $blog;*/?>


<a href=#top class="to-top">Ke atas</a>

</form>
</div>
</body>
</html>